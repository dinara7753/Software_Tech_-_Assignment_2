import cv2
img1 = cv2.imread('1_Gammar.PNG')
img2 = cv2.imread('1_Limniu.PNG')
img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
blended = cv2.addWeighted(img1, 0.6, img2_resized, 0.4, 0)
cv2.imshow('Blended Image', blended)
cv2.waitKey(0)
cv2.destroyAllWindows()
