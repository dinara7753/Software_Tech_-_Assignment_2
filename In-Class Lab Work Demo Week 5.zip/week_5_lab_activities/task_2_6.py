import cv2
image = cv2.imread('1_Gammar.PNG')
print(f"Original pixel value at (50, 50): {image[50, 50]}")
image[50, 50] = [255, 255, 255]
cv2.imwrite('modified.png', image)