import cv2
image = cv2.imread('1_Gammar.PNG')
print(f"Type of the image: {type(image)}")
print(f"Shape of the image array:{image.shape}")
