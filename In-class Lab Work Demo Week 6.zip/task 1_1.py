#task 1
import matplotlib.pyplot as plt
from keras.preprocessing.image import load_img

# load the image
img_path = '/content/2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG'
img = load_img(img_path)

# report details about the image
print(type(img))
print(img.format)
print(img.mode)
print(img.size)

# show the image using matplotlib
plt.imshow(img)
plt.axis('off')
plt.show()