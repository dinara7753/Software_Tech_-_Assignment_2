#task 2
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.preprocessing.image import array_to_img

# load the image
img_path = '/content/2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG'
img = load_img(img_path)
print(type(img))

# convert to numpy array
img_array = img_to_array(img)
print(img_array.dtype)
print(img_array.shape)

# convert back to image
img_pil = array_to_img(img_array)
print(type(img_pil))