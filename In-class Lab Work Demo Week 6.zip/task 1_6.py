#task 6
# Example of centering an image dataset (MNIST)
from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# 1. Load dataset
(trainX, trainY), (testX, testY) = mnist.load_data()

# 2. Reshape to add a single channel
trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))
testX = testX.reshape((testX.shape[0], 28, 28, 1))

# 3. Report mean pixel values BEFORE centering
print('Means before centering: train=%.3f, test=%.3f' % (trainX.mean(), testX.mean()))

# 4. Create generator that performs feature-wise centering
datagen = ImageDataGenerator(featurewise_center=True)

# 5. Compute the mean from the training dataset
datagen.fit(trainX)

# Instead of datagen.mean_, compute manually:
print('Training set mean (manual): %.3f' % trainX.mean())

# 6. Demonstrate effect on a single batch
iterator = datagen.flow(trainX, trainY, batch_size=64)
batchX, batchY = next(iterator)
print('Single batch shape:', batchX.shape)
print('Single batch mean after centering: %.3f' % batchX.mean())

# 7. Demonstrate effect on the entire training dataset
iterator_full = datagen.flow(trainX, trainY, batch_size=len(trainX), shuffle=False)
batchX_full, batchY_full = next(iterator_full)
print('Full dataset batch shape:', batchX_full.shape)
print('Full dataset mean after centering: %.3f' % batchX_full.mean())