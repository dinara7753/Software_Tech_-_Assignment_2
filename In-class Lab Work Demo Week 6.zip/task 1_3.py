#task 3
import matplotlib.pyplot as plt
import os

from keras.preprocessing.image import load_img
from keras.preprocessing.image import save_img
from keras.preprocessing.image import img_to_array

# 1. Load your insect image as grayscale
img_path = '/content/2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG'
img = load_img(img_path, color_mode='grayscale')

# 2. Convert to numpy array
img_array = img_to_array(img)

# 3. Save the grayscale image
save_dir = os.path.dirname(img_path)   # saves in the same folder
save_filename = 'insect_grayscale.jpg'
full_save_path = os.path.join(save_dir, save_filename)

save_img(full_save_path, img_array)

# 4. Reload the saved image
img_reloaded = load_img(full_save_path)

# 5. Print details
print(type(img_reloaded))
print(img_reloaded.format)
print(img_reloaded.mode)
print(img_reloaded.size)

# 6. Display the image
plt.imshow(img_reloaded, cmap='gray')
plt.axis('off')
plt.show()