#task 7
# Example of standardizing an image dataset (MNIST)
from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# 1. Load dataset
(trainX, trainY), (testX, testY) = mnist.load_data()

# 2. Reshape to add a single channel
trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))
testX = testX.reshape((testX.shape[0], 28, 28, 1))

# 3. Report pixel means and standard deviations BEFORE standardization
print('Before: train mean=%.3f (std=%.3f), test mean=%.3f (std=%.3f)' %
      (trainX.mean(), trainX.std(), testX.mean(), testX.std()))

# 4. Create generator that centers AND normalizes by std
datagen = ImageDataGenerator(
    featurewise_center=True,
    featurewise_std_normalization=True
)

# 5. Fit generator on training data (computes mean + std)
datagen.fit(trainX)

# Manually print the mean and std used for standardization
print('Training mean (manual): %.3f' % trainX.mean())
print('Training std (manual): %.3f' % trainX.std())

# 6. Test effect on a single batch
iterator = datagen.flow(trainX, trainY, batch_size=64)
batchX, batchY = next(iterator)
print('Single batch:', batchX.shape, 'mean=%.3f std=%.3f' %
      (batchX.mean(), batchX.std()))

# 7. Test effect on the entire dataset
iterator_full = datagen.flow(trainX, trainY, batch_size=len(trainX), shuffle=False)
batchX_full, batchY_full = next(iterator_full)
print('Full dataset:', batchX_full.shape, 'mean=%.3f std=%.3f' %
      (batchX_full.mean(), batchX_full.std()))