#task 5
# Normalising the MNIST dataset
from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# 1. Load dataset
(trainX, trainY), (testX, testY) = mnist.load_data()

# 2. Reshape to add a single channel (28, 28, 1)
trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))
testX = testX.reshape((testX.shape[0], 28, 28, 1))

# 3. Confirm pixel value range BEFORE scaling
print('Before scaling:')
print('Train min=%.3f, max=%.3f' % (trainX.min(), trainX.max()))
print('Test min=%.3f, max=%.3f' % (testX.min(), testX.max()))

# 4. Create ImageDataGenerator that rescales pixels to 0–1
datagen = ImageDataGenerator(rescale=1.0/255.0)

# 5. Create iterators (batches of 64 images)
train_iterator = datagen.flow(trainX, trainY, batch_size=64)
test_iterator = datagen.flow(testX, testY, batch_size=64)

# 6. Check batch count
print('Train batches:', len(train_iterator))
print('Test batches:', len(test_iterator))

# 7. Confirm scaling works by inspecting one batch
batchX, batchY = next(train_iterator)
print('After scaling:')
print('Batch shape =', batchX.shape)
print('min=%.3f, max=%.3f' % (batchX.min(), batchX.max()))