#task 4
# Load and summarise the MNIST dataset
from keras.datasets import mnist

# 1. Load dataset
(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

# 2. Summarise dataset shapes
print('Train:', train_images.shape, train_labels.shape)
print('Test:', test_images.shape, test_labels.shape)

# 3. Summarise pixel values
print('Train pixel stats:', train_images.min(), train_images.max(), train_images.mean(), train_images.std())
print('Test pixel stats:', test_images.min(), test_images.max(), test_images.mean(), test_images.std())